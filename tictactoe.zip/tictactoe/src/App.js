import logo from './logo.svg';
import './App.css';
import React from 'react';
import Game from './components/Game'


class App extends React.Component{
  render(){
    return(
      <Game/>
    )
  }
}

export default App;
